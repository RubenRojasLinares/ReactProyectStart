﻿
using SharpCompress.Archives;
using SharpCompress.Common;
using System;
using System.IO;
using System.IO.Compression;

namespace UnrarProyect
{
    class Program
    {
        static void Main(string[] args)
        {
            IArchive archive = ArchiveFactory.Open(@"C:\Users\robenrob\Desktop\RubenNuevoProyecto\examplereactwebpage.rar");

             
            foreach (var entry in archive.Entries)
            {
                if (!entry.IsDirectory){
                    Console.WriteLine(entry.Key);
                    entry.WriteToDirectory(@"C:\Users\robenrob\Desktop\RubenNuevoProyecto ",new ExtractionOptions { ExtractFullPath=true,Overwrite=true});
                   // entry.WriteToDirectory("C:\unrar", new ExtractionOptions with { ExtractFullPath = true, Overwrite = true });
                }
            };
 
            Console.WriteLine("Hello World!");
        }
    }
}
